module.exports = {
    labels: require('./labels.json'),
    scoringStrategy: require('./scoring-strategy')
};
